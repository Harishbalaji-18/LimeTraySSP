package com.example.demo.model;

public class Admin {

	 String name;
	@Override
	public String toString() {
		return "Admin [name=" + name + ", userid=" + userid + ", phone=" + phone + ", email=" + email + ", getName()="
				+ getName() + ", getUserid()=" + getUserid() + ", getPhone()=" + getPhone() + ", getEmail()="
				+ getEmail() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	 String userid;
	 int phone;
	 String email;
	
	
	
}