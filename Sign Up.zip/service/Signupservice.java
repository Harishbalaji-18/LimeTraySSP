package com.example.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.SignupDAO;
import com.example.demo.model.Admin;


@Service
public class Signupservice {
	@Autowired
	SignupDAO dao;

	public ArrayList<Admin> display() {
		return dao.displayUser();
	}

	

}
	